package com.hotel.service.impl;

import java.util.List;

import com.hotel.entities.Room;
import com.hotel.entities.RoomNumber;
import com.hotel.service.RoomNumberService;

public class RoomNumberServiceImpl implements RoomNumberService {

	@Override
	public List<RoomNumber> getAllRoomNumber() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Room getRoomById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

}
